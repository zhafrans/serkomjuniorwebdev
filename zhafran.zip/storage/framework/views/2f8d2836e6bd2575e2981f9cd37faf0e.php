

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <h2 class="text-center">Hasil Pendaftaran</h2>

    <?php if($daftarItems->count() > 0): ?>
        <table class="table mt-4">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Nomor HP</th>
                    <th>Semester</th>
                    <th>IPK</th>
                    <th>Pilihan Beasiswa</th>
                    <th>Berkas</th> <!-- Added column for the file -->
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $daftarItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($daftar->nama); ?></td>
                        <td><?php echo e($daftar->email); ?></td>
                        <td><?php echo e($daftar->no_hp); ?></td>
                        <td><?php echo e($daftar->semester); ?></td>
                        <td><?php echo e($daftar->ipk); ?></td>
                        <td><?php echo e($daftar->pilihanbeasiswa); ?></td>
                        <td>
                            <a href="<?php echo e(asset('' . $daftar->berkas)); ?>" target="_blank">Lihat Berkas</a>
                        </td>
                        <td><?php echo e($daftar->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-center">Tidak ada data pendaftaran.</p>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATA Institut Teknologi Telkom Pwt\serkom_beasiswa\resources\views/hasil.blade.php ENDPATH**/ ?>