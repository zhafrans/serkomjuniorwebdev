

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2 class="text-center">DAFTAR BEASISWA</h2>
    <form method="POST" action="<?php echo e(route('daftar.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="nama">Masukkan Nama:</label>
            <input type="text" class="form-control" id="nama" placeholder="Masukkan nama" name="nama" value="<?php echo e(old('nama')); ?>" required>
            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="email">Masukkan Email:</label>
            <input type="email" class="form-control" id="email" placeholder="Masukkan email" name="email" value="<?php echo e(old('email')); ?>" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="nomorHp">Nomor HP:</label>
            <input type="tel" class="form-control" id="nomorHp" placeholder="Nomor HP" name="no_hp" value="<?php echo e(old('no_hp')); ?>" required>
            <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="semester">Semester Saat Ini:</label>
            <select class="form-control" id="semester" name="semester" oninput="calculateIpk()" required>
                <option value="" <?php echo e(old('semester') == '' ? 'selected' : ''); ?>>Pilih</option>
                <option value="1" <?php echo e(old('semester') == '1' ? 'selected' : ''); ?>>1</option>
                <option value="2" <?php echo e(old('semester') == '2' ? 'selected' : ''); ?>>2</option>
                <option value="3" <?php echo e(old('semester') == '3' ? 'selected' : ''); ?>>3</option>
                <option value="4" <?php echo e(old('semester') == '4' ? 'selected' : ''); ?>>4</option>
                <option value="5" <?php echo e(old('semester') == '5' ? 'selected' : ''); ?>>5</option>
                <option value="6" <?php echo e(old('semester') == '6' ? 'selected' : ''); ?>>6</option>
                <option value="7" <?php echo e(old('semester') == '7' ? 'selected' : ''); ?>>7</option>
                <option value="8" <?php echo e(old('semester') == '8' ? 'selected' : ''); ?>>8</option>
                
            </select>
            <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="ipk">IPK Terakhir:</label>
            <input type="text" class="form-control" id="ipk" placeholder="IPK" readonly name="ipk" value="<?php echo e(old('ipk')); ?>" required>
        </div>
        <div class="form-group">
            <label for="pilihanBeasiswa">Pilihan Beasiswa:</label>
            <select class="form-control" id="pilihanBeasiswa" name="pilihanbeasiswa" required>
                <option value="" <?php echo e(old('pilihanbeasiswa') == '' ? 'selected' : ''); ?>>Pilih</option>
                <option value="Beasiswa Akademik" <?php echo e(old('pilihanbeasiswa') == 'Beasiswa Akademik' ? 'selected' : ''); ?>>Beasiswa Akademik</option>
                <option value="Beasiswa Non-Akademik" <?php echo e(old('pilihanbeasiswa') == 'Beasiswa Non-Akademik' ? 'selected' : ''); ?>>Beasiswa Non-Akademik</option>
                <option value="Beasiswa Penghargaan" <?php echo e(old('pilihanbeasiswa') == 'Beasiswa Penghargaan' ? 'selected' : ''); ?>>Beasiswa Penghargaan</option>
            </select>
            <?php $__errorArgs = ['pilihanbeasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="berkasSyarat">Upload Berkas Syarat:</label>
            <input type="file" class="form-control-file" id="berkasSyarat" name="berkas" required>
            <?php $__errorArgs = ['berkas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary" id="daftarButton">Daftar</button>
            <a href="<?php echo e(route('pilihanbeasiswa')); ?>"><button type="button" class="btn btn-secondary">Batal</button></a>
        </div>

        
        <?php if($errors->any()): ?> 
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

    </form>
</div>

<script>
    // fungsi javascript untuk menentukan ipk berdasarkan semester
    document.addEventListener("DOMContentLoaded", function () {
    calculateIpk();
});

function calculateIpk() {
    var semester = document.getElementById("semester").value;
    var ipkInput = document.getElementById("ipk");
    var pilihanBeasiswa = document.getElementById("pilihanBeasiswa");
    var berkasSyarat = document.getElementById("berkasSyarat");
    var daftarButton = document.getElementById("daftarButton");

    var ipkMap = {
        1: 3.8,
        2: 3.9,
        3: 3.7,
        4: 3.4,
        5: 2.7,
        6: 2.9,
        7: 2.8,
        8: 3,
    };

    // Check if semester is undefined or not selected
    var calculatedIpk = semester !== '' ? ipkMap[semester] : '';

    ipkInput.value = calculatedIpk;

    // If semester is not selected, disable inputs and button
    if (semester === '') {
        pilihanBeasiswa.disabled = true;
        berkasSyarat.disabled = true;
        daftarButton.disabled = true;
    } else {
        // If semester is selected, enable inputs and button
        pilihanBeasiswa.disabled = false;
        berkasSyarat.disabled = false;
        daftarButton.disabled = false;
        pilihanBeasiswa.focus();
    }
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATA Institut Teknologi Telkom Pwt\serkom_beasiswa\resources\views/daftar.blade.php ENDPATH**/ ?>